package com.zerock.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zerock.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	/*create table member(
			id varchar(50) primary key,
			pw varchar(50),
			name varchar(50),
			regdate datetime default current_timestamp
			);*/
	
	@Autowired
	private MemberService member;
	
	
	
	//회원가입 화면처리
	@RequestMapping("/join")
	public String join() {
		return "member/join";
	}
	//로그인 화면처리
	@RequestMapping("/login")
	public String login() {
		return "member/login";
	}
	
	//ajax요청 받기
	@RequestMapping("/checkId")
	@ResponseBody//리턴을 view리졸버로 전달하지 않고,해당메서드를 호출한 곳으로 결과를 반환 
	public int checkId(@RequestParam("id") String id) {
		
		int result=member.idCheck(id);
		System.out.println("아이디 개수:"+result);
		
		return result;
	}

}
