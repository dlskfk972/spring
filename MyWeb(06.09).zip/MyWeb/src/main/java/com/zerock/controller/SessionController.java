package com.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mysql.cj.Session;

@Controller
@RequestMapping("/session")
public class SessionController {

	//1.main화면처리
	@RequestMapping("/mainPage")
	public String mainPage() {
		return "session/mainPage";
	}
	//2.loginPage화면 처리
	@RequestMapping("/loginPage")
	public String loginPage() {
		return "session/loginPage";
	}
	
	//3.myPage화면처리
	@RequestMapping("/myPage")
	public String myPage(HttpSession session) {
		/*//8.세션에 test_id가 없다면 loginPage로 리다이렉트
		if(session.getAttribute("test_id")==null){
		return "redirect:/session/loginPage";
		}*/
		return "session/myPage";
	}
	//4.정보 수정 페이지 처리
	@RequestMapping("/updatePage")
	public String updatePage(HttpSession session) {
		/*//9.세션에 test_id가 없다면 loginPage로 리다이렉트
		if(session.getAttribute("test_id")==null){
			return "redirect:/session/loginPage";
			}
		*/
		return "session/updatePage";
	}
	//5.로그인 폼 처리
	@RequestMapping("/sessionLogin")
	public String sessionLogin(@RequestParam("id")String id,@RequestParam("pw") String pw
			,HttpSession session
			,RedirectAttributes RA
			) {
		//5.아이디 abc 비밀번호가 1234라면 로그인 성공이라 가정
		if(id.equals("abc")&&pw.equals("1234")) {
			session.setAttribute("test_id",id);
			session.setAttribute("test_name", "홍길자");
			return "redirect:/session/myPage";
		}
		//10.아이디 비밀번호가 틀렸을 경우,리다이렉트 이동에서 일회성!!!데이터로 파라미터값을 전달하고 싶을때 사용
		RA.addFlashAttribute("msg","아이디 비밀번호를 다시 확인해주세요");
		return "redirect:/session/loginPage";
	}
	//6.로그아웃
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		//session.removeAttribute("test_id");//특정 세션 삭제
		session.invalidate();
		return "redirect:/session/mainPage";
	}
}
