package com.zerock.member.mapper;

public interface MemberMapper {
	
	public int idCheck(String id);//아이디 중복체크

}
