package com.zerock.member.service;

public interface MemberService {
	
	public int idCheck(String id);//아이디 중복 체크
	

}
