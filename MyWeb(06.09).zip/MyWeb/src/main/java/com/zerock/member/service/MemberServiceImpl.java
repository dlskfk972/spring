package com.zerock.member.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zerock.member.mapper.MemberMapper;

@Service("member")
public class MemberServiceImpl implements MemberService{

	@Autowired
	private MemberMapper mapper;
	
	
	@Override
	public int idCheck(String id) {
		int result=mapper.idCheck(id);
		
		return result;
	}

}
