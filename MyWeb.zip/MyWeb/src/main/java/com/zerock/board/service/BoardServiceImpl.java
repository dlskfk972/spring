package com.zerock.board.service;

import com.zerock.board.command.BoardVO;


public class BoardServiceImpl implements BoardService {

	@Override
	public void regist(BoardVO vo) {
		//ȭ�鿡�� �Ѿ�� name,content,title���
		
		
	}
	
	

}
