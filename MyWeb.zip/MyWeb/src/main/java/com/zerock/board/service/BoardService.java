package com.zerock.board.service;

import com.zerock.board.command.BoardVO;

public interface BoardService {
	
	
	public void regist(BoardVO vo);

}
