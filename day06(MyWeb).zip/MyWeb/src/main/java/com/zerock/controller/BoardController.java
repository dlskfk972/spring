package com.zerock.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.zerock.board.command.BoardVO;
import com.zerock.board.service.BoardService;

@Controller
@RequestMapping("/board")
public class BoardController {
//	create table tbl_board(
//			
//		    num int auto_increment primary key,
//		    title varchar(200) not null,
//		    content varchar(2000) not null,
//		    writer varchar(50) not null,
//			regdate datetime default current_timestamp
//	);
	
	//1.controller구현
	//2.테이블 생성
	//3.DB관련 설정(root-xml)
	//4.BoardVO커맨드 생성
	//5.Service객체 생성
	
	@Autowired
	private BoardService service;
	
	
	
	//등록 화면 처리
	@RequestMapping("/register")
	public String register() {
		
		return "board/register";
	}
	//리스트 화면 처리
	@RequestMapping("/list")
	public String list(Model model) {
		
		ArrayList<BoardVO> list = service.getList();
		//화면에 값을 전달할때 Model를 메서드의 매개변수에 선언
		//addAttibute("식별이름", 값)
		model.addAttribute("board_list", list);
		
		return "board/list";
	}
	
	//등록요청 처리
	@RequestMapping("/regist")
	public String regist(BoardVO vo) {
		
		//1.BoardServiceImpl 에 @Service("이름") 선언
		//2.servlet-xml에 컴포넌스캔명령
		//3.멤버변수로 service객체 선언
		//4.autowired로 자동주입명령
		//5.메서드에서 호출
		service.regist(vo);
		
		//response.sendRedirect() 를 대신하는 redirect:/
		return "redirect:/board/list";
	}
	
//	//상세보기 화면 처리 (/content 요청이 들어오면 content.jsp화면으로)
//	@RequestMapping("/content")
//	public String content(@RequestParam("num") int num, Model model) {
//		
//		BoardVO vo = service.getContent(num);
//		model.addAttribute("board_content", vo);
//		
//		
//		return "board/content";
//	}
//	
//	//1. modify요청을 받는 메서드 생성
//	//2. service의 getContent() 메서드를 재활용해서 해당 게시물의 상세정보를 조회.
//	//3. modify.jsp 화면으로 이동  
//	//수정 페이지 처리
//	@RequestMapping("/modify")
//	public String modify(@RequestParam("num") int num, Model model) {
//		
//		BoardVO vo = service.getContent(num);
//		model.addAttribute("board_content", vo);
//		
//		return "board/modify";
//	}
	
	//상세보기와 수정페이지는 기능이 동일 -> 한번에 하나의 메서드로 처리방법
	@RequestMapping({"/content", "/modify" })
	public void content(@RequestParam("num") int num, Model model) {
		
		BoardVO vo = service.getContent(num);
		model.addAttribute("board_content", vo);
		//void형 메서드는 요청받은 페이지를 리졸버 뷰에 전달합니다.
	}
	
	//게시판 수정완료 버튼
	//1. update 요청을 받을 수 있는 메서드 생성
	//2. service 계층에 전달받은 폼값을 전달받는 update(vo) 를 생성
	//3. service 계층에서는 myBatis로 연결하는 boardUpdate(vo) 를 생성
	//sql = update tbl_board set title= ?, content=?, writer=?, 
	//			updatedate=current_timestamp where num= ?
	//DB작업 처리후 list화면으로 이동
	@RequestMapping("/update")
	public String update(BoardVO vo) {
		
		service.update(vo);
		
		int num = vo.getNum(); 
		return "redirect:/board/content?num=" + num; 
	}
	
	//1. delete라는 요청을 처리하는 메서드 생성
	//2. service계층에 num을 전달받는 delete(?)를 생성
	//3. mapper인터페이스에 deleteBoard(?)를 생성
	//4. mapper.xml에서는 <delete> 태그를 통해 삭제를 진행
	//5. sql = delete from tbl_board where num = ?
	//6. 삭제 후엔 list.jsp로 이동
	
	@RequestMapping("/delete")
	public String delete(@RequestParam("num") int num) {
		
		service.delete(num);
		
		return "redirect:/board/list";
	}
	
}






