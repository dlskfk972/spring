package com.zerock.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/session")
public class SessionController {

	//1.main화면처리
	@RequestMapping("/mainPage")
	public String mainPage() {
		return "session/mainPage";
	}
	//2.loginPage화면 처리
	@RequestMapping("/loginPage")
	public String loginPage() {
		return "session/loginPage";
	}
	
	//3.myPage화면처리
	@RequestMapping("/myPage")
	public String myPage() {
		return "session/myPage";
	}
	//4.정보 수정 페이지 처리
	@RequestMapping("/updatePage")
	public String updatePage() {
		return "session/updatePage";
	}
	//5.로그인 폼 처리
	@RequestMapping("/sessionLogin")
	public String sessionLogin(@RequestParam("id")String id,@RequestParam("pw") String pw
			,HttpSession session
			
			) {
		//5.아이디 abc 비밀번호가 1234라면 로그인 성공이라 가정
		if(id.equals("abc")&&pw.equals("1234")) {
			session.setAttribute("test_id",id);
			session.setAttribute("test_name", "홍길자");
			return "redirect:/session/myPage";
		}
		
		return "redirect:/session/loginPage";
	}
	//6.로그아웃
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		//session.removeAttribute("test_id");//특정 세션 삭제
		session.invalidate();
		return "redirect:/session/mainPage";
	}
}
